package com.seu_pacote.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.seu_pacote.data.database.TaskDao

@Composable
fun TaskListScreen(taskDao: TaskDao) {
    // Implementação da tela de lista de tarefas
}
