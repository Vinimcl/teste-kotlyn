package com.seu_pacote.data.database

import androidx.room.Database
import androidx.room.RoomDatabase
import com.seu_pacote.data.model.Task
import com.seu_pacote.data.model.Category

@Database(entities = [Task::class, Category::class], version = 1)
abstract class AppDatabase : RoomDatabase() {
    abstract fun taskDao(): TaskDao
    abstract fun categoryDao(): CategoryDao
}
