package com.seu_pacote.data.database

import androidx.room.*
import com.seu_pacote.data.model.Category

@Dao
interface CategoryDao {
    @Insert
    suspend fun insert(category: Category)

    @Query("SELECT * FROM categories")
    suspend fun getAllCategories(): List<Category>
}
