package com.seu_pacote.data.api

import retrofit2.http.GET
import com.seu_pacote.data.model.Task

interface TaskApi {
    @GET("tasks")
    suspend fun getTasks(): List<Task>
}
