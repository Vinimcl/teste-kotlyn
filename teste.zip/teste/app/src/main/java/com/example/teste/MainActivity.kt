package com.seu_pacote

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.room.Room
import com.seu_pacote.data.database.AppDatabase
import com.seu_pacote.ui.screens.TaskListScreen
import com.seu_pacote.viewmodel.TaskViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val db = Room.databaseBuilder(
            applicationContext,
            AppDatabase::class.java,
            "app_database"
        ).build()

        setContent {
            TaskListScreen(db.taskDao())
        }
    }
}
